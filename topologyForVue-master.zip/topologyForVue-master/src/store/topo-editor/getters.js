export const getTopoConfigData = (state) => {
    return state.topoData;
};

export const getSelectedComponents = (state) => {
    return state.selectedComponents;
};